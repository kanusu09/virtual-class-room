
package kunal;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
public class Studentregi extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//System.out.println("hiii");
		String no = req.getParameter("roll_no");
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		//String degree = req.getParameter("degree");
		//String course = req.getParameter("course");
		//String year = req.getParameter("year");
	
	try{
		Connection con=DBConnection.getConn();


        PreparedStatement ps=con.prepareStatement("insert into student  values(?, ?, ?, ?)");

        ps.setString(1,no);
        ps.setString(2,name);
        ps.setString(3,email);
        ps.setString(4,password);
       // ps.setString(5,degree);
       // ps.setString(6,course);
        //ps.setString(7,year);


        int i=ps.executeUpdate();
    	HttpSession session = req.getSession();
        if(i>0){
           
	//Appointment appointment = new Appointment(userId, fullName, gender, age, appointmentDate, email, phone, diseases, doctorId, address, "Pending");
	
	//AppointmentDAO appointmentDAO = new AppointmentDAO(DBConnection.getConn());
	//boolean f = appointmentDAO.addAppointment(appointment);
	
	//get session

	
	//if(f==true) {
		
		session.setAttribute("successMsg", "registration is recorded Successfully.");
		resp.sendRedirect("student_login.jsp");
		
		
	}
	else {
		
		session.setAttribute("errorMsg", "Something went wrong on server!");
		resp.sendRedirect("Student_register.jsp");
		
	}
	}catch(Exception d){
		d.printStackTrace();
		}

		}}
