package kunal;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


/**
 * Servlet implementation class userlogin
 */
public class userlogin extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String roll_no = req.getParameter("roll_no");
		String password = req.getParameter("password");
		System.out.println(roll_no);
		System.out.println(password);
		
		HttpSession session = req.getSession();
		try {
			Connection con=DBConnection.getConn();
			String sql = "select * from student where roll_no=? and password=?";

			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, roll_no);
			pstmt.setString(2, password);

			ResultSet resultSet = pstmt.executeQuery();
			System.out.println(resultSet);
			 if(resultSet.next()) {
				 System.out.println("hii");
				 
				 session.setAttribute("successMsg", "login Successfully.");
			resp.sendRedirect("student_dashboard.jsp"); 
		}
		else {
			System.out.println("bii");
			session.setAttribute("errorMsg","Invalid email or password");
			resp.sendRedirect("student_login.jsp"); 
		}}catch(Exception d){
		d.printStackTrace();
		}

		}
}
